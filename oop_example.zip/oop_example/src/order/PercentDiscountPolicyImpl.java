package order;

import member.Grade;
import member.Member;

public class PercentDiscountPolicyImpl implements DiscountPolicy{

	private int percent;
	public PercentDiscountPolicyImpl(int percent) {
		this.percent=percent;
	}
	@Override
	public int discount(int price, Member member) {
		if(member.getGrade()==Grade.VIP) {
			return price *(percent/100);
		}
		return 0;
	}

}
