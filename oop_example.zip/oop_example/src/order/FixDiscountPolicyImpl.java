package order;

import member.Grade;
import member.Member;

public class FixDiscountPolicyImpl implements DiscountPolicy{

	@Override
	public int discount(int price, Member member) {
		if(member.getGrade()==Grade.VIP) {
			return price-1500;
		}
		return 0;
	}

}
