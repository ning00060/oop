package order;

import member.Member;

public interface DiscountPolicy {

	int discount(int price,Member member);
}
