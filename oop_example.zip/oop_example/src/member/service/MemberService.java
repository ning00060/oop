package member.service;

import java.util.Collection;

import member.Member;

public interface MemberService {

	void signUp(Member member);
	Member findById(Long memId);
	Collection<Member> findAll();
}
