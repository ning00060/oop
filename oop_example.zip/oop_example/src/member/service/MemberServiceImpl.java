package member.service;

import java.util.Collection;

import member.Member;
import member.repository.MemberRepository;

public class MemberServiceImpl implements MemberService{

	private MemberRepository repository;
	
	public MemberServiceImpl(MemberRepository memberRepository) {
		this.repository=memberRepository;
	}
	@Override
	public void signUp(Member member) {
		repository.save(member);
		
	}

	@Override
	public Member findById(Long memId) {
		return repository.findById(memId);
	}
	@Override
	public Collection<Member> findAll() {
		
		return repository.findAll();
	}

}
