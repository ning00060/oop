package member;

import member.repository.DBMemberRepositoryImpl;
import member.repository.MemberRepository;
import member.repository.MemoryMemberRepositoryImpl;
import member.service.MemberService;
import member.service.MemberServiceImpl;

public class MainTest1 {

	public static void main(String[] args) {
		
		MemberRepository dBMemberRepository=new DBMemberRepositoryImpl();
		MemberRepository memoeyMemberRepository= MemoryMemberRepositoryImpl.getInstance();
		MemberService memberService=new MemberServiceImpl(memoeyMemberRepository);
		
		
		//기존
		Member member=memberService.findById(1L);

		// 신규
		//요청
		Member newMember=new Member(100L, "연습", Grade.VIP);
		memberService.signUp(newMember);
		
		System.out.println(member);
		System.out.println(memberService.findById(2L));
		System.out.println(memberService.findById(100L));
		System.out.println(newMember);
		System.out.println(memberService.findAll().toString());
	}
}
