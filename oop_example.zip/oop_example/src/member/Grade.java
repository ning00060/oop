package member;

public enum Grade {
	BASIC,VIP
}
