package member.repository;

import java.util.Collection;
import java.util.List;

import member.Member;

public interface MemberRepository {

	void save(Member member);
	Member findById(Long memId);
	Collection<Member> findAll();
}
