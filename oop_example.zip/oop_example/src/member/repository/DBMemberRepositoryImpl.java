package member.repository;

import java.util.List;

import member.Member;

public class DBMemberRepositoryImpl implements MemberRepository{

	private static DBMemberRepositoryImpl instance;
	public DBMemberRepositoryImpl getInstacne() {
		if(instance==null) {
			instance=new DBMemberRepositoryImpl();
		}
		return instance;
	}
	@Override
	public void save(Member member) {
		
		
	}

	@Override
	public Member findById(Long memId) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Member> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
